#!/system/bin/sh

MODPATH="${0%/*}"
SCRIPTPATH="$MODPATH/scripts"
log() { echo "[LynxSlamModule] $*" >&2; }

# log "Before Sleep"
# sleep 1
# log "After Sleep"

# Hook "after overlayfs"
if [ -x "$SCRIPTPATH/after_overlayfs.sh" ]; then
  log "Running after_overlayfs.sh"
  "$SCRIPTPATH/after_overlayfs.sh" || log "after_overlayfs.sh exited with $?"
fi

# ---------- 2) Post-boot hook ----------
(
  BOOT_TIMEOUT=300
  j=0
  until [ "$(getprop sys.boot_completed)" = "1" ]; do
    [ $j -ge $BOOT_TIMEOUT ] && { log "Timeout waiting sys.boot_completed"; exit 0; }
    [ $((j%10)) -eq 0 ] && log "Waiting sys.boot_completed..."
    sleep 1
    j=$((j+1))
  done

  if [ -x "$SCRIPTPATH/post_boot.sh" ]; then
    log "Running post_boot.sh"
    "$SCRIPTPATH/post_boot.sh" || log "post_boot.sh exited with $?"
  fi
) &

exit 0