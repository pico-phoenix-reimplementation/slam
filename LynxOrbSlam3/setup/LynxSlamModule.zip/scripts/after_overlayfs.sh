#!/system/bin/sh
LOGTAG="LynxSlamModule/after_overlayfs"
log() { echo "[$LOGTAG] $*" >&2; }


setenforce 0
magic_remount_rw
rm -rf /vendor/lib/rfsa/adsp/testsig*
magic_remount_ro
setenforce 1

log "after_overlayfs done."