#!/system/bin/sh
LOGTAG="LynxSlamModule/post_boot"
log() { echo "[$LOGTAG] $*" >&2; }


setenforce 0
magic_remount_rw
cp /vendor/lib/rfsa/adsp_testsig_backup/* /vendor/lib/rfsa/adsp/
chmod 644 /vendor/lib/rfsa/adsp/testsig-*
chmod 666 /dev/cvp*
magic_remount_ro

log "post_boot done."