#!/system/bin/sh

ui_print "[LynxSlamModule] Installing..."
mkdir -p "$MODPATH/scripts"

unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'scripts/*'  -d "$MODPATH" >&2

chmod 0755 "$MODPATH/service.sh"
chmod 0755 "$MODPATH/scripts/"*

ui_print "[LynxSlamModule] Done."